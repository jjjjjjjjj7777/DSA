/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package linkedList;

/**
 *
 * @author abdullahabbas
 */
public class TrainApp {
    public static void main(String[] args) {
        // Create a RefSortedList for FreightCar objects sorted by capacity
        RefSortedList<FreightCar> train = new RefSortedList<>();

        // Add FreightCar objects to the train
        train.add(new FreightCar(1, "Coal", 50.5));
        train.add(new FreightCar(2, "Grain", 40.0));
        train.add(new FreightCar(3, "Oil", 60.0));
        train.add(new FreightCar(4, "Grain", 30.0));

        // Display the train sorted by capacity
        System.out.println("Train sorted by capacity: " + train);

        
        RefSortedList<FreightCar> grainCars = filterByType(train, "Grain");
        System.out.println("Freight cars with type 'Grain': " + grainCars);
    }

    // Static method to filter by type
    public static RefSortedList<FreightCar> filterByType(RefSortedList<FreightCar> train, String cargoType) {
        RefSortedList<FreightCar> filteredList = new RefSortedList<>();
        for (FreightCar car : train.getList()) {
            if (car.getType().equalsIgnoreCase(cargoType)) {
                filteredList.add(car);
            }
        }
        return filteredList;
    }
}