/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package linkedList;

/**
 *
 * @author abdullahabbas
 */
public class FreightCar {
    private Integer id;
    private String type;
    private double capacity;
    
    public FreightCar(Integer id, String type, double capacity){
        this.id=id;
        this.type=type;
        this.capacity=capacity;
    }
    public Integer getId(){
        return id;
    }
    public void setId(Integer id){
        this.id=id;
    }
    public String getType(){
        return type;
    }
    public void setType(String type){
        this.type=type;
    }
    public double getCapacity(){
        return capacity;
    }
    public void setCapacity(double capacity){
        this.capacity=capacity;
    }

    @Override
    public String toString() {
         return "FreightCar{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", capacity=" + capacity +
                '}';
    }
}
